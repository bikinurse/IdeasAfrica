<?php
include_once("struct/header.php");

  
include_once("pages/home.php");


include_once("struct/footer.php");

?>
