<?php

?>
<div class="container" style="margin-top:40px;">
<br/>

<div class="row-fluid">
<div class="span3">&nbsp;</div>
<div class="span6">

<div class="row-fluid">
<div class="span2">&nbsp;</div>
<div class="span8">
<form action="login.php" method="POST">
<h2 align="center">Login</h2>
<hr/>
<label>Email</label>
<input type="text" name="email" style="height:30px;width:97%"/>
<br/>

<label>Password</label>
<input type="password" name="password" style="height:30px;width:97%"/>

<br/>
<input type="submit" value="Login" class="btn btn-primary btn-large" />

<span style="float:right"><a href="./twitter_login.php" class="btn" title="Login with Twitter"><img src="assets/img/twitter-icon.png"/> <b>Login With Twitter</b></a></span><br/>
<a href="#" class="greyed">Forgot password?</a>
</form>
<div align="">
<div class="greyed" align="">
<hr/>
<span class="greyed">You do not have an account?</span>
<a href="./?&signup=1" class="" style="font-size:1.5em"> Join...</a><br/>
</div
</div>
<!--<hr/>
>-->

</div>
<div class="span2">

</div>
</div>


</div>

<div class="span3">

</div>
</div>


</div>