<div class="container" style="margin-top:40px;">
<hr/><?php
$company_id = (int) $_GET['startup'];

$company = DBase::table_row($company_id,'companies');

//print_r($company);
//echo "c".$company_id;
?>

<div class="row-fluid">
<div class="span2"><img  src="logos/<?php echo $company['logo']!="" ? $company['logo']:"no-logo.png"?>" style="max-width:150px"/></div>
<div class="span8">
<?php echo $company['name']!=NULL ? "<h2>".$company['name']."</h2>":""?>
<?php echo $company['description']!=NULL ? "<span style='font-weight:bold'>".$company['description']."</span>":""?>


<?php

$markets = Insight::company_markets($company_id);
if($markets){
	$markets = implode(', ',$markets);
}
?>
<div class="greyed"><?php echo $markets;?></div>
<?php echo $company['website']!=NULL ? "<div><a href='http://".$company['website']."'>".$company['website']."</a></div>":""?>
</div>
<div class="span2" align="right">
<div class="NoofFollowers">
<span class="" id="folowers"style="font-size:3em" ><?php echo Insight::company_followers($_GET['startup'])?></span><br/>
<span class="greyed">Followers</span>
</div>
<?php
if(isset($_SESSION['id'])){
	if(is_follower($_SESSION['id'])){
		?>
		<button class="btn span12 unfollow"  cid="<?php echo $_GET['startup']?>" id="unfollow" data-loading-text="Following..."><strong>Unfollow</strong></button>
		<?php
		}else{
		
		?>
		<button href="#" cid="<?php echo $_GET['startup']?>" class="btn span12 follow"><b>Follow</b></button>
		<?php
	}
	}else{
	?>
	<a href="#" class="btn"><b><span class="greyed">Please login to Follow</span></b></a>
	<?php
}
?>


</div>
</div>
<hr/>



<div class="row-fluid">


<div class="span8">

<div class="tabbable">
<ul class="nav nav-tabs">
<li class="active">
<a data-toggle="tab" href="#product" class="active">Product Description</a>
</li>
<li><a data-toggle="tab" href="#activity">Activity</a></li>
<li><a data-toggle="tab" href="#followers">Followers</a></li>
</ul>
<div class="tab-content">
<div class="tab-pane active" id="product" =>

<!--<h6>Product Description</h6>-->

<?php echo $company['productDescription']!=NULL ? "<span style='font-weight:bold'>".$company['productDescription']."</span>":""?>
</div>


<div id="activity" class="tab-pane">
<!--Activity-->
<?php
$activities = DBase::table_row_ids("company_activities where company_id='$company_id'");

if(!empty($activities)){
	?>
	<div >
	<?php
	foreach($activities as $activity_id){
		$activity = DBase::table_row($activity_id,"company_activities");
		//print_r($activity);
		$activity_details = DBase::table_row($activity['activity_id'],"activities");
		$user = DBase::table_row($activity['user_id'],"users");
		$company = DBase::table_row($activity['company_id'],"companies");
		?>
		<li><br/><img src="<?php echo $user['oauth_provider']=='manual'? "profilePic/".$user['profilePic'] : "https://api.twitter.com/1/users/profile_image?screen_name=".$user['username']."&size=mini"?>" height="25"> <b><a href="#"><?php echo $user['oauth_provider']=='manual'? $user['name'] : $userInfo->name;?></a>  <?php echo $activity_details['activity'];?> <a href="#"><?php echo $company['name']?></a></b></li>
		<?php
	}
	?>
	<?php
}
?>
</div>


</div>
<div id="followers" class="tab-pane">
<!--Comments-->
<?php
$followers = DBase::table_row_ids("company_followers where company_id = '$company_id'");
//print_r($followers);

if(!empty($followers)){
	foreach($followers as $followers_id){
		$following = DBase::table_row($followers_id,'company_followers');
		$person = DBase::table_row($following['user_id'],"users");
		?>
		<div class="row-fluid" style="margin-top:5px;background:#f7f7f7">
		<div class="span3" align="right">
		<img src="profilePic/user.png" height="50"/>
		</div>
		<div class="span4">
		<b><?php echo $person['name'] != NULL? $person['name']:"";?></b>
		<p><?php echo $person['mini_bio'] != NULL? $person['mini_bio']:"";?></p>
		<div class="greyed">
		<?php echo $person['college'] != NULL? "went to ".$person['college']."&bull;":"";?>
		<?php echo $person['work'] != NULL? "works at ".$person['work']:"";?>
		</div>
		</div>
		</div>
		<?php
	}
}

?>

</div>


</div>

</div>
</div>

<div class="span4">
<h4><?php echo $company['name']!=NULL ? "".$company['name']."'s":""?> team</h4>
<br/>

<ul class="nav nav-list">
<li class="nav-header">Founders</li>
<li><a href="#">Sam Gichuru</a></li>
<li><a href="#">Ekiru Timothy</a></li>


<li class="nav-header">Investors</li>
<li><a href="#">Pedro Tornado</a></li>
<li><a href="#">Millan Maria</a></li>


<li class="nav-header">Referees</li>
<li><a href="#">Venturer Waititu</a></li>
<li><a href="#">Lodepe Missionary</a></li>


<li class="nav-header">Employees</li>
<li><a href="#">Sam Gichuru</a></li>
<li><a href="#">Ekiru Timothy</a></li>
</ul>
<?php

?>

</div>



</div>

</div>