<?php

?>
<div>
<h1>People</h1>
<hr/>
</div>