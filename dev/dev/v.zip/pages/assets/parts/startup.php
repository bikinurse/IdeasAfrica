<div class="container" style="margin-top:40px;">
<hr/><?php
$company_id = (int) $_GET['startup'];

$company = DBase::table_row($company_id,'companies');

//print_r($company);
//echo "c".$company_id;
?>

<div class="row-fluid">
<div class="span2"><img  src="logos/<?php echo $company['logo']!="" ? $company['logo']:"no-logo.png"?>" style="max-width:150px"/></div>
<div class="span9">
<?php echo $company['name']!=NULL ? "<h2>".$company['name']."</h2>":""?>
<?php echo $company['description']!=NULL ? "<span style='font-weight:bold'>".$company['description']."</span>":""?>


<?php

$markets = Insight::company_markets($company_id);
if($markets){
	$markets = implode(', ',$markets);
}
?>
<div class="greyed"><?php echo $markets;?></div>
<?php echo $company['website']!=NULL ? "<div><a href='http://".$company['website']."'>".$company['website']."</a></div>":""?>
</div>
<div class="span1" align="right">
<a href="#" class="btn">Follow</a>

</div>
</div>
<hr/>

<div class="">

<h6>Product Description</h6>
<?php echo $company['productDescription']!=NULL ? "<span style='font-weight:bold'>".$company['productDescription']."</span>":""?>
<div class="">
<br/><br/>
<h6>Resent Activities</h6>
<?php
$activities = DBase::table_row_ids("company_activities where company_id='$company_id'");

if(!empty($activities)){
	?>
	<div >
	<?php
	foreach($activities as $activity_id){
		$activity = DBase::table_row($activity_id,"company_activities");
		$activity_details = DBase::table_row($activity['activity_id'],"activities");
		$user = DBase::table_row($activity['user_id'],"users");
		$company = DBase::table_row($activity['company_id'],"companies");
		?>
		<li><img src="https://api.twitter.com/1/users/profile_image?screen_name=<?php echo $user['username']?>&size=mini "> <b><a href="#"><?php echo $userInfo->name;?></a>  <?php echo $activity_details['activity'];?> <a href="#"><?php echo $company['name']?></a></b></li>
		<?php
	}
	?>
	<?php
}
?>
</div>
</div>


</div>

</div>