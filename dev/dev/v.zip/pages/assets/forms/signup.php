<?php

?>
<div class="container" style="margin-top:40px;">
<br/>

<div class="row-fluid">
<div class="span3">&nbsp;</div>
<div class="span6">

<div class="row-fluid">
<div class="span3">&nbsp;</div>
<div class="span6">
<form action="kernel/signup.php" method="POST">
<h2 align="center">Sign up</h2>
<hr/>
<label>Name</label>
<input type="text" name="name"  style="height:30px;width:98%"/>
<br/>

<label>Email</label>
<input type="text" name="email" style="height:30px;width:98%"/>
<br/>


<label>Password</label>
<input type="password" name="password" style="height:30px;width:98%"/>



<br/><br/>
<div align="">
<input type="submit" value="Sign up" class="btn btn-primary btn-large" />
<a href="./twitter_login.php" class="btn" title="Sign Up with Twitter"><img src="assets/img/twitter-icon.png"/><b> Sign up with twitter</b></a>
</div>
<hr/>
<div class="" align="">
<a href="./?&login=1" class="">I have an account</a>
</div>

</form>
<div class="span3">&nbsp;</div>
</div>
</div>


</div>

<div class="span3">&nbsp;</div>
</div>


</div>