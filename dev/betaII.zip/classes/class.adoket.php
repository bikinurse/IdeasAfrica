<?php
class Adoket{
	static public function save_data($data,$db_table,$db_field){
		
	}
}
?>