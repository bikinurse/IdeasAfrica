<div class="IAfooter" align="center">
Ideas Africa &copy;2012
<div class="greyed" style="color:#c5c5c5"> Made by <a href="http://about.me/ekiru" style="">Ekiru</a></div>
 </div>
   <script type="text/javascript" src="http://platform.twitter.com/widgets.js"></script>
    <script src="assets/js/jquery.js"></script>
    <script src="assets/js/google-code-prettify/prettify.js"></script>
    <script src="assets/js/bootstrap-transition.js"></script>
    <script src="assets/js/bootstrap-alert.js"></script>
    <script src="assets/js/bootstrap-modal.js"></script>
    <script src="assets/js/bootstrap-dropdown.js"></script>
    <script src="assets/js/bootstrap-scrollspy.js"></script>
    <script src="assets/js/bootstrap-tab.js"></script>
    <script src="assets/js/bootstrap-tooltip.js"></script>
    <script src="assets/js/bootstrap-popover.js"></script>
    <script src="assets/js/bootstrap-button.js"></script>
    <script src="assets/js/bootstrap-collapse.js"></script>
    <script src="assets/js/bootstrap-carousel.js"></script>
    <script src="assets/js/bootstrap-typeahead.js"></script>
    
	
	<script src="assets/js/jquery.autogrow.js"></script>
	<script src="assets/js/jquery-ui-1.8.22.custom.min.js"></script>
	<script src="assets/js/jquery.form.js"></script>
    
	
	<script src="assets/js/ideas.js"></script>
	
</body>
</html>