<?php

?>
<div align="center">
<br/>
<h1>Welcome to IdeasAfrica</h1>
<hr/>
<a href="./?n=p" class="btn"><b>Create a Startup</b>..</a><br/>
<br/>
<a href="./?n=i" class="btn"><b>I am an Investor</b>..</a><br/>
<br/>
<a href="./">Discover Ideas In Africa</a>
<br/><br/><br/>
</div>